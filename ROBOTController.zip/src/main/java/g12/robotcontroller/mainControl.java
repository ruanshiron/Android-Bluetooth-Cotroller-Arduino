package g12.robotcontroller;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.UUID;

/**
 * Created by hienn on 3/11/2018.
 */


public class mainControl extends AppCompatActivity {
    //////
    private boolean deleteThreadRunning = false;
    private boolean cancelDeleteThread = false;
    private Handler handler = new Handler();
    /////
    TextView command, precommand, preprecommand;
    ImageButton Up, Rec, Right, Left, Disconnect, Change, Square, Circle, Triangle;
    String address = null;
    private ProgressDialog progress;
    BluetoothAdapter myBluetooth = null;
    BluetoothSocket btSocket = null;
    private boolean isConnected = false;
    private final int REQ_CODE_SPEECH_INPUT = 100;
    //UUI
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected  void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);

        Intent newint = getIntent();
        address = newint.getStringExtra(DeviceList.EXTRA_ADDRESS);

        setContentView(R.layout.main_control);

        new ConnectBT().execute(); //Call the class to connect
        //credit = (TextView)findViewById(R.id.credit);
        command = (TextView) findViewById(R.id.command);
        precommand = (TextView) findViewById(R.id.precommand);
        preprecommand = (TextView) findViewById(R.id.preprecommand);
                //widget
        Up = (ImageButton) findViewById(R.id.upButton);
        Rec = (ImageButton) findViewById(R.id.recButton);
        Right = (ImageButton) findViewById(R.id.rightButton);
        Left = (ImageButton) findViewById(R.id.leftButton);
        Disconnect = (ImageButton)findViewById(R.id.discnt);
        Change = (ImageButton) findViewById(R.id.change);
        Square = (ImageButton) findViewById(R.id.square);
        Triangle = (ImageButton) findViewById(R.id.triangle);
        Circle = (ImageButton) findViewById(R.id.circle);


        Up.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction())
                {
                    case MotionEvent.ACTION_DOWN:
                    {
                        Up.setImageResource(R.drawable.chevron_act);
                        handleDeleteDown();
                        return true;
                    }

                    case MotionEvent.ACTION_UP:
                    {
                        Up.setImageResource(R.drawable.chevron_right);
                        handleDeleteUp();
                        return true;
                    }

                    default:
                        return false;
                }

            }
            private void handleDeleteDown() {

                if (!deleteThreadRunning)
                    startDeleteThread();
            }

            private void startDeleteThread() {

                Thread r = new Thread() {

                    @Override
                    public void run() {
                        try {

                            deleteThreadRunning = true;
                            while (!cancelDeleteThread) {

                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        turn("forward");
                                        preprecommand.setText(precommand.getText().toString());
                                        precommand.setText(command.getText().toString());
                                        command.setText("forward");
                                    }
                                });

                                try {
                                    Thread.sleep(100);
                                } catch (InterruptedException e) {
                                    throw new RuntimeException(
                                            "Could not wait between char delete.", e);
                                }
                            }
                        }
                        finally
                        {
                            deleteThreadRunning = false;
                            cancelDeleteThread = false;
                        }
                    }
                };

                // actually start the delete char thread
                r.start();
            }

        });

        Right.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction())
                {
                    case MotionEvent.ACTION_DOWN:
                    {
                        Right.setImageResource(R.drawable.chevron_act);
                        handleDeleteDown();
                        return true;
                    }

                    case MotionEvent.ACTION_UP:
                    {
                        Right.setImageResource(R.drawable.chevron_right);
                        handleDeleteUp();
                        return true;
                    }

                    default:
                        return false;
                }

            }
            private void handleDeleteDown() {

                if (!deleteThreadRunning)
                    startDeleteThread();
            }

            private void startDeleteThread() {

                Thread r = new Thread() {

                    @Override
                    public void run() {
                        try {

                            deleteThreadRunning = true;
                            while (!cancelDeleteThread) {

                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        turn("right");
                                        preprecommand.setText(precommand.getText().toString());
                                        precommand.setText(command.getText().toString());
                                        command.setText("right");
                                    }
                                });

                                try {
                                    Thread.sleep(100);
                                } catch (InterruptedException e) {
                                    throw new RuntimeException(
                                            "Could not wait between char delete.", e);
                                }
                            }
                        }
                        finally
                        {
                            deleteThreadRunning = false;
                            cancelDeleteThread = false;
                        }
                    }
                };

                // actually start the delete char thread
                r.start();
            }

        });


        Left.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction())
                {
                    case MotionEvent.ACTION_DOWN:
                    {
                        Left.setImageResource(R.drawable.chevron_act);
                        handleDeleteDown();
                        return true;
                    }

                    case MotionEvent.ACTION_UP:
                    {
                        Left.setImageResource(R.drawable.chevron_right);
                        handleDeleteUp();
                        return true;
                    }

                    default:
                        return false;
                }

            }
            private void handleDeleteDown() {

                if (!deleteThreadRunning)
                    startDeleteThread();
            }

            private void startDeleteThread() {

                Thread r = new Thread() {

                    @Override
                    public void run() {
                        try {

                            deleteThreadRunning = true;
                            while (!cancelDeleteThread) {

                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        turn("left");
                                        preprecommand.setText(precommand.getText().toString());
                                        precommand.setText(command.getText().toString());
                                        command.setText("left");
                                    }
                                });

                                try {
                                    Thread.sleep(100);
                                } catch (InterruptedException e) {
                                    throw new RuntimeException(
                                            "Could not wait between char delete.", e);
                                }
                            }
                        }
                        finally
                        {
                            deleteThreadRunning = false;
                            cancelDeleteThread = false;
                        }
                    }
                };

                // actually start the delete char thread
                r.start();
            }

        });

        Rec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preprecommand.setText(precommand.getText().toString());
                precommand.setText(command.getText().toString());
                promptSpeechInput();
            }
        });

        Disconnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (btSocket!=null) //If the btSocket is busy
                {
                    try
                    {
                        btSocket.close(); //close connection
                    }
                    catch (IOException e)
                    { msg("Error");}
                }
                finish(); //return to the first layout
            }
        });

        Change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Up.getVisibility()==View.VISIBLE) {
                    Up.setVisibility(View.GONE);
                    Left.setVisibility(View.GONE);
                    Right.setVisibility(View.GONE);
                    Square.setVisibility(View.VISIBLE);
                    Triangle.setVisibility(View.VISIBLE);
                    Circle.setVisibility(View.VISIBLE);

                } else {
                    Up.setVisibility(View.VISIBLE);
                    Left.setVisibility(View.VISIBLE);
                    Right.setVisibility(View.VISIBLE);
                    Square.setVisibility(View.GONE);
                    Triangle.setVisibility(View.GONE);
                    Circle.setVisibility(View.GONE);
                }
            }
        });

        Square.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                turn("square");
                preprecommand.setText(precommand.getText().toString());
                precommand.setText(command.getText().toString());
                command.setText("square");
            }
        });

        Triangle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                turn("triangle");
                preprecommand.setText(precommand.getText().toString());
                precommand.setText(command.getText().toString());
                command.setText("triangle");
            }
        });

        Circle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                turn("circle");
                preprecommand.setText(precommand.getText().toString());
                precommand.setText(command.getText().toString());
                command.setText("circle");
            }
        });



    }

    private void handleDeleteUp() {
        cancelDeleteThread = true;
    }


    //Show the Speech Dialog
    private void promptSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                getString(R.string.saysomethings));
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.speech_not_supported),
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Receiving speech input
     * */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {

                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    command.setText(result.get(0));
                    turn(result.get(0).toLowerCase());
                }
                break;
            }

        }
    }


    private void turn(String cmd)
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write(cmd.toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    // fast way to call Toast
    private void msg(String s)
    {
        Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_control, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();
        if(id == R.id.action_settings){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private class ConnectBT extends AsyncTask<Void, Void, Void>  // UI thread
    {
        private boolean ConnectSuccess = true; //if it's here, it's almost connected

        @Override
        protected void onPreExecute()
        {
            progress = ProgressDialog.show(mainControl.this, "Connecting...", "Please wait!!!");  //show a progress dialog
        }

        @Override
        protected Void doInBackground(Void... devices) //while the progress dialog is shown, the connection is done in background
        {
            try
            {
                if (btSocket == null || !isConnected)
                {
                    myBluetooth = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
                    BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);//connects to the device's address and checks if it's available
                    btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    btSocket.connect();//start connection
                }
            }
            catch (IOException e)
            {
                ConnectSuccess = false;//if the try failed, you can check the exception here
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) //after the doInBackground, it checks if everything went fine
        {
            super.onPostExecute(result);

            if (!ConnectSuccess)
            {
                msg("Connection Failed. Is it a SPP Bluetooth? Try again.");
                finish();
            }
            else
            {
                msg("Connected.");
                isConnected = true;
            }
            progress.dismiss();
        }
    }
}
