package g12.robotcontroller;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/**
 * Created by Nguyen Vinh on 07/03/2018.
 */

public class Splash extends Activity {
    @Override
    protected void onCreate(Bundle saveInstanceState){

        super.onCreate(saveInstanceState);
        setContentView(R.layout.splash);

        Thread timerThread = new Thread(){
            public void run()
            {
                try
                {
                    sleep(1000);
                }
                catch(InterruptedException e)
                {

                }finally{
                    Intent intent = new Intent(Splash.this,DeviceList.class);
                    startActivity(intent);
                }
            }
        };
        timerThread.start();
    }

    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        finish();
    }
}
